package com.example.ggcmap;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.Menu;
import android.widget.Toast;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    private Button button;



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.floor3:
                // Logout selected
                Toast.makeText(this, "this is the option settings", Toast.LENGTH_LONG).show();
                return true;

            case R.id.About:
                // About selected
                Toast.makeText(this, "this is the option about", Toast.LENGTH_LONG).show();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button =  findViewById(R.id.floor1Button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              openFirstFloor();
            }
        });


        button =  findViewById(R.id.floor2Button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSecondFloor();
            }
        });

        button =  findViewById(R.id.floor3Button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openThirdFloor();
            }
        });

        button =  findViewById(R.id.campusButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCampusMap();
            }
        });

        button =  findViewById(R.id.aboutButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAbout();
            }
        });


    }

    public void openFirstFloor() {
        Intent intent = new Intent(this, FirstFloor.class);
        startActivity(intent);
    }

    public void openSecondFloor() {
        Intent intent = new Intent(this, SecondFloor.class);
        startActivity(intent);
    }

    public void openThirdFloor() {
        Intent intent = new Intent(this, ThirdFloor.class);
        startActivity(intent);
    }

    public void openCampusMap() {
        Intent intent = new Intent(this, Campus.class);
        startActivity(intent);
    }

    public void openAbout() {
        Intent intent = new Intent(this, About.class);
        startActivity(intent);
    }
}
