package com.example.myapplication;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;

public class CustomDrawable extends Drawable {

    @Override
    public void draw(Canvas canvas) {
        // All drawing done here
    }

    @Override
    public void setAlpha(int alpha) {
        // alpha determines transparency
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
        // Gives the ColorFilter
    }

    @Override
    public int getOpacity() {
        // Must be PixelFormat.UNKNOWN, TRANSLUCENT, TRANSPARENT, or OPAQUE
        return PixelFormat.OPAQUE;
    }
}