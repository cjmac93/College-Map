package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.graphics.drawable.AnimationDrawable;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView myAnim = findViewById(R.id.anima);

        final AnimationDrawable myAnimation = (AnimationDrawable) myAnim.getBackground();

        int duration = 0;
        for (int i = 0; 1 < myAnimation.getNumberOfFrames();
             i++)
            duration += myAnimation.getDuration(i);


        myAnimation.start();
    }
}
